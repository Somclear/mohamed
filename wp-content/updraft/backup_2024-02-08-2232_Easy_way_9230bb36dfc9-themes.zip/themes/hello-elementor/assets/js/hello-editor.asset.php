<?php return array('dependencies' => array(), 'version' => 'e467b0db4be3ce9829ae');
